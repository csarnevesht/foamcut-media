FoamCut rotary example: solid foam baluster

Files:
- revolution_baluster.dat: side profile (X = radius, Y = height, millimeters).
  Source dimensions: 190.5 mm high, 76.2 mm maximum diameter.
- rotation_circle.dat: closed, unit-radius circular section.
- twist_zero.dat: zero degrees of twist throughout the height.

Open Rotary / TwistRot, then Settings. Load the side profile with Load Polyline,
the circular section with Load Closed Polyline, and zero twist with Load Twist Curve.
The part-height setting may rescale the imported profile. To retain the source
height, turn off Scale custom revolution to part height in Revolution Profile.
The circular section is normalized to the profile radius; leave real-size section
scaling off. This is a solid turned form with no hollow interior or sculpted details.

Close Settings and inspect the 3D view. Generate Path, play the simulation, and
check Tapered / Table. Download > Table G-code exports table-style G-code. Review machine
units, clearances, feed rates, and axis mapping for the intended machine setup.

Recording source:
demos/demo-files/advanced-workflows-rotary-foam-baluster.demo.txt
